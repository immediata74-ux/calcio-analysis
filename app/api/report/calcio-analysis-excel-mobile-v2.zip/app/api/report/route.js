import ExcelJS from 'exceljs';
import { buildTopAnalysis } from '../../../lib/analysis/engine';
import { football } from '../../../lib/api-football';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export const maxDuration = 60;

const C = {
  black: '000000',
  white: 'FFFFFF',
  muted: 'A7A7A7',
  border: '2B2B2B',
  yellow: 'FFD54A',
  green: '45D483',
  orange: 'FF9F43',
  cyan: '63D8FF',
};

function pct(v) {
  return Number.isFinite(v) ? `${v}%` : 'N.D.';
}

function fixtureLabel(f) {
  return `${f?.teams?.home?.name || 'N.D.'} — ${f?.teams?.away?.name || 'N.D.'}`;
}

function key(v) {
  return String(v || '')
    .toLowerCase()
    .replace(/[–—-]/g, '-')
    .replace(/\s+/g, ' ')
    .trim();
}

function formatTime(value) {
  if (!value) return 'N.D.';
  try {
    return new Intl.DateTimeFormat('it-IT', {
      timeZone: 'Europe/Rome',
      hour: '2-digit',
      minute: '2-digit',
      hour12: false,
    }).format(new Date(value));
  } catch {
    return 'N.D.';
  }
}

function fixtureLookup(fixtures) {
  const map = new Map();
  for (const f of fixtures || []) map.set(key(fixtureLabel(f)), f);
  return map;
}

function timeOf(signal, lookup) {
  const f = lookup.get(key(signal?.fixture || signal?.name));
  return formatTime(f?.fixture?.date);
}

function statusOf(x) {
  return x?.details?.lineup || x?.status || 'PRE-LINEUP';
}

function blackCanvas(ws, usedCols = 6, rows = 180) {
  ws.views = [{
    state: 'frozen',
    ySplit: 4,
    showGridLines: false,
    zoomScale: 100,
  }];
  ws.properties.defaultRowHeight = 34;

  for (let r = 1; r <= rows; r += 1) {
    const row = ws.getRow(r);
    for (let c = 1; c <= usedCols; c += 1) {
      const cell = row.getCell(c);
      cell.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: C.black },
      };
      cell.font = {
        name: 'Arial',
        size: 13,
        color: { argb: C.white },
      };
      cell.alignment = {
        vertical: 'middle',
        wrapText: true,
      };
      cell.border = {
        bottom: { style: 'hair', color: { argb: C.border } },
      };
    }
  }
}

function title(ws, text, subtitle, accent, lastCol = 'F') {
  ws.mergeCells(`A1:${lastCol}1`);
  ws.getCell('A1').value = text;
  ws.getCell('A1').font = {
    name: 'Arial',
    bold: true,
    size: 20,
    color: { argb: accent },
  };
  ws.getCell('A1').alignment = { vertical: 'middle' };
  ws.getRow(1).height = 38;

  ws.mergeCells(`A2:${lastCol}2`);
  ws.getCell('A2').value = subtitle;
  ws.getCell('A2').font = {
    name: 'Arial',
    size: 12,
    color: { argb: C.muted },
  };
  ws.getCell('A2').alignment = {
    vertical: 'middle',
    wrapText: true,
  };
  ws.getRow(2).height = 42;
}

function header(ws, accent) {
  const row = ws.getRow(4);
  row.height = 38;
  row.eachCell({ includeEmpty: true }, cell => {
    cell.fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: C.black },
    };
    cell.font = {
      name: 'Arial',
      bold: true,
      size: 13,
      color: { argb: accent },
    };
    cell.alignment = {
      vertical: 'middle',
      horizontal: 'center',
      wrapText: true,
    };
    cell.border = {
      top: { style: 'thin', color: { argb: accent } },
      bottom: { style: 'thin', color: { argb: accent } },
    };
  });
}

function body(ws) {
  for (let r = 5; r <= ws.rowCount; r += 1) {
    const row = ws.getRow(r);
    row.height = 46;
    row.eachCell({ includeEmpty: true }, cell => {
      cell.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: C.black },
      };
      cell.font = {
        name: 'Arial',
        size: 13,
        color: { argb: C.white },
      };
      cell.alignment = {
        vertical: 'middle',
        wrapText: true,
      };
      cell.border = {
        bottom: { style: 'hair', color: { argb: C.border } },
      };
    });
  }
}

function probability(cell, value, accent) {
  cell.font = {
    name: 'Arial',
    bold: true,
    size: 16,
    color: { argb: accent },
  };
  cell.alignment = {
    vertical: 'middle',
    horizontal: 'center',
  };
}

function finish(ws, accent, widths) {
  blackCanvas(ws, widths.length, 180);
  header(ws, accent);
  body(ws);
  ws.columns = widths.map(width => ({ width }));
  ws.autoFilter = { from: 'A4', to: `F${Math.max(4, ws.rowCount)}` };
}

function summarySelection(x, kind) {
  if (kind === 'CORNER') return `${x.fixture || x.name || 'N.D.'}\nOver 8.5`;
  return `${x.name || 'N.D.'}\n${x.fixture || 'N.D.'}`;
}

function summaryDetail(x, kind) {
  if (kind === 'AMMONITO') {
    return `Gialli/90 ${x.details?.rate90 ?? 'N.D.'} • Min ${x.details?.expectedMinutes ?? 'N.D.'}\n${statusOf(x)}`;
  }
  if (kind === 'MARCATORE') {
    return `Gol/90 ${x.details?.rate90 ?? 'N.D.'} • Min ${x.details?.expectedMinutes ?? 'N.D.'}\n${statusOf(x)}`;
  }
  return `Attesi ${x.details?.expectedCorners ?? 'N.D.'} • O7.5 ${pct(x.details?.over75)} • O9.5 ${pct(x.details?.over95)}`;
}

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const date = searchParams.get('date') || '';
  const league = searchParams.get('league') || '';

  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
    return Response.json(
      { error: 'Data richiesta nel formato YYYY-MM-DD' },
      { status: 400 },
    );
  }

  try {
    const [analysis, fixtureData] = await Promise.all([
      buildTopAnalysis({ date, league }),
      football.fixturesByDate(date),
    ]);

    const lookup = fixtureLookup(fixtureData?.response || []);
    const wb = new ExcelJS.Workbook();
    wb.creator = 'Calcio Analysis';
    wb.created = new Date();

    // =========================================================
    // RIEPILOGO MOBILE - 6 colonne, caratteri grandi, tutto nero
    // =========================================================
    const summary = wb.addWorksheet('Riepilogo');
    summary.addRow([]);
    summary.addRow([]);
    summary.addRow([]);
    summary.addRow(['Tipo', 'Ora', 'Campionato', 'Selezione', '%', 'Dati']);

    const summaryMeta = [];

    for (const x of analysis.cards || []) {
      summary.addRow([
        'AMMONITO',
        timeOf(x, lookup),
        x.league || 'N.D.',
        summarySelection(x, 'AMMONITO'),
        pct(x.percent),
        summaryDetail(x, 'AMMONITO'),
      ]);
      summaryMeta.push({ kind: 'AMMONITO', value: x.percent });
    }

    for (const x of analysis.scorers || []) {
      summary.addRow([
        'MARCATORE',
        timeOf(x, lookup),
        x.league || 'N.D.',
        summarySelection(x, 'MARCATORE'),
        pct(x.percent),
        summaryDetail(x, 'MARCATORE'),
      ]);
      summaryMeta.push({ kind: 'MARCATORE', value: x.percent });
    }

    for (const x of analysis.corners || []) {
      const p = x.details?.over85 ?? x.percent;
      summary.addRow([
        'CORNER',
        timeOf(x, lookup),
        x.league || 'N.D.',
        summarySelection(x, 'CORNER'),
        pct(p),
        summaryDetail(x, 'CORNER'),
      ]);
      summaryMeta.push({ kind: 'CORNER', value: p });
    }

    finish(summary, C.cyan, [14, 8, 18, 38, 9, 30]);
    title(
      summary,
      'CALCIO ANALYSIS — RIEPILOGO',
      `Data ${date} • ora italiana • ammoniti, marcatori e corner in un solo foglio leggibile da cellulare`,
      C.cyan,
    );

    summaryMeta.forEach((m, i) => {
      const row = summary.getRow(i + 5);
      const accent = m.kind === 'AMMONITO' ? C.yellow : m.kind === 'MARCATORE' ? C.green : C.orange;
      row.getCell(1).font = { name: 'Arial', bold: true, size: 13, color: { argb: accent } };
      probability(row.getCell(5), m.value, accent);
    });

    // =========================================================
    // AMMONITI
    // =========================================================
    const cards = wb.addWorksheet('Ammoniti');
    cards.addRow([]);
    cards.addRow([]);
    cards.addRow([]);
    cards.addRow(['#', 'Ora', 'Campionato', 'Giocatore / Partita', '%', 'Dati']);
    (analysis.cards || []).forEach((x, i) => {
      cards.addRow([
        i + 1,
        timeOf(x, lookup),
        x.league || 'N.D.',
        `${x.name || 'N.D.'}\n${x.fixture || 'N.D.'}`,
        pct(x.percent),
        `Gialli/90 ${x.details?.rate90 ?? 'N.D.'} • Min ${x.details?.expectedMinutes ?? 'N.D.'}\n${statusOf(x)}`,
      ]);
    });
    finish(cards, C.yellow, [5, 8, 18, 39, 9, 30]);
    title(cards, 'TOP AMMONITI', `Data ${date} • ora e campionato inclusi`, C.yellow);
    (analysis.cards || []).forEach((x, i) => probability(cards.getRow(i + 5).getCell(5), x.percent, C.yellow));

    // =========================================================
    // MARCATORI
    // =========================================================
    const scorers = wb.addWorksheet('Marcatori');
    scorers.addRow([]);
    scorers.addRow([]);
    scorers.addRow([]);
    scorers.addRow(['#', 'Ora', 'Campionato', 'Giocatore / Partita', '%', 'Dati']);
    (analysis.scorers || []).forEach((x, i) => {
      scorers.addRow([
        i + 1,
        timeOf(x, lookup),
        x.league || 'N.D.',
        `${x.name || 'N.D.'}\n${x.fixture || 'N.D.'}`,
        pct(x.percent),
        `Gol/90 ${x.details?.rate90 ?? 'N.D.'} • Min ${x.details?.expectedMinutes ?? 'N.D.'}\n${statusOf(x)}`,
      ]);
    });
    finish(scorers, C.green, [5, 8, 18, 39, 9, 30]);
    title(scorers, 'TOP MARCATORI', `Data ${date} • ora e campionato inclusi`, C.green);
    (analysis.scorers || []).forEach((x, i) => probability(scorers.getRow(i + 5).getCell(5), x.percent, C.green));

    // =========================================================
    // CORNER
    // =========================================================
    const corners = wb.addWorksheet('Corner');
    corners.addRow([]);
    corners.addRow([]);
    corners.addRow([]);
    corners.addRow(['#', 'Ora', 'Campionato', 'Partita', 'O8.5', 'Dati']);
    (analysis.corners || []).forEach((x, i) => {
      const p = x.details?.over85 ?? x.percent;
      corners.addRow([
        i + 1,
        timeOf(x, lookup),
        x.league || 'N.D.',
        x.fixture || x.name || 'N.D.',
        pct(p),
        `Attesi ${x.details?.expectedCorners ?? 'N.D.'}\nO7.5 ${pct(x.details?.over75)} • O9.5 ${pct(x.details?.over95)} • O10.5 ${pct(x.details?.over105)}`,
      ]);
    });
    finish(corners, C.orange, [5, 8, 18, 39, 10, 32]);
    title(corners, 'TOP CORNER', `Data ${date} • ora e campionato inclusi`, C.orange);
    (analysis.corners || []).forEach((x, i) => {
      probability(corners.getRow(i + 5).getCell(5), x.details?.over85 ?? x.percent, C.orange);
    });

    const buffer = await wb.xlsx.writeBuffer();

    return new Response(buffer, {
      headers: {
        'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'Content-Disposition': `attachment; filename="calcio-analysis-${date}.xlsx"`,
        'Cache-Control': 'no-store',
      },
    });
  } catch (error) {
    return Response.json(
      { error: error?.message || 'Errore generazione Excel' },
      { status: error?.status || 500 },
    );
  }
}
